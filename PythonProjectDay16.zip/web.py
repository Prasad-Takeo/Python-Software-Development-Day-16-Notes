##web - ?
"""
web - a system of internet servers that support specifically formatted documents. HTML, Audio, Video, graphics

How tbe web works - ?

www.facebook.com ->  ?

Like humans, we are recognise by our name but computer will always remember by number

IP: 0.0.0.0 to 255.255.255.255

Most important terms of WWW

Client-
 An application ( Chrome, FireFox, Safari ) that runs on a computer and is connected to the internet.
 Primary role is to take user interactions and tranlsate them into requests to another computer called a web server

Server -
    A machine that is connected to the internet and also has an IP address.
    server respons to client request
    unlike the client which also has an IP, the server has special software installed and running which tells it
    how to respond to incoming requests
    many types of servers - web servers, database servers, file servers, application servers and more ( web server )

IP address - Internet Protocol Address.
    Numerical Identifier for a device on a TCP/IP network
    Every computer on the internet has an IP address that it uses to identify and communicate with other computers
    In order to locate a device in the network, the logical IP address is converted to a physical address by the
    TCP/IP software, This physical address ( MAC address ) is built into your hardware

        A -> B ( IP table )
          -> C

ISP - Internet Service Provider.
        ISP is the middle man between client and server, Generally it's a "cable company"

DNS - Domain Name System
    A distributed database which keeps track of computer's domain names and their corresponding IP address on the internet

Domain Name
    Used to identify one or more IP address. facebook.com -> get the ip

TCP/IP
   used as a standard for transmitting data over networks

Port Number
    16 bit integer (0 to 65535).
    specific port on the server and serves as a identifier to forward the network requests

    Computer A is a client -> 8443 <- Applicaiton A
    Computer B is a server
            8443 - Application A
            27017 - Application B

Host
    It could be computer connected to a network, can be a client, server or any other type of device.
    Each Host has a unique IP address

    www.google.com -> host will be web server that serves the web pages

    server and host
    server - is a specific type of host
    host - entire organization that providing a hosting service to maintain multiple web servers

    www.facebook.com -> x.x.x.x ->  host (deployed server) -> server

    AWS cloud -> EC2 instance -> Application A

    you can run server from a host

    Single Computer - Chat, Game Application
    Web server 1 -> Chat -> 5432
    Web server 2 -> Game -> 6455

    client -> chat.mylocal.com -> x.x.x.x:5432 -> x.x.x.x -> 5432 -> request

HTTP - Hyper-text Transfer Protocol. that web browsers and web servers used to communicate with each other
       over the internet.

URL - Uniform Resource Locators.
        https://www.facebook.com/SugumarVenkatesan -> specific resource to identify the user on the facebook

    https -> protocol, facebook -> host name, SugumarVenkatesan -> resource name (or) file name
"""

"""
gmail -> www.gmail.com

Login -> POST (send username,password) request to www.gmail.com/LoginService and the gmail will return in response an authentication token

Javascript, Session, Cookie - authentication token 

gmail -> token already exist in the session -> directly to inbox

ip, visiting time

amazon -> Monday Apr 12 

-> Thursday APr 14 -> Last visited on Monday Apr 12 

"""

"""
Web Service - API - Application Programming Interface

software A - Ecommerce - Java
software B - Payment - C++
Software C - Invoice - Python

Web service - To integrate the different applications developed in different language under common Web Service Protocol

REST /  SOAP Protocol

REST - GET, POST, PUT, PATCH, DELETE

Software A can call the API of Payment to integrate the payment solution with it.

Github
 API -> Database
 
 Developing a software B which uses GitHUB API, 
    /GetUser/Sugumar -> API will call it -> return a response
    
 Github USER API - CRUD
 
 create User - POST /create/user/<sugumar>
 get User - GET /get/user/<sugumar>
 delete user - DELETE /delete/user/<sugumar>
    
    
 Read about ISO-OSI layers:
 Physical
 DataLink
 Network
 Transport
 Session
 Presentation
 Application
"""